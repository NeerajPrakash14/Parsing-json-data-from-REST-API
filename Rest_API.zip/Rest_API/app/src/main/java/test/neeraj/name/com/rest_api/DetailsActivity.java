package test.neeraj.name.com.rest_api;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import static test.neeraj.name.com.rest_api.MainActivity.EXTRA_CREATERNAME;
import static test.neeraj.name.com.rest_api.MainActivity.EXTRA_LIKES;
import static test.neeraj.name.com.rest_api.MainActivity.EXTRA_URL;

public class DetailsActivity extends AppCompatActivity {

     ImageView imageView;
     TextView creater;
     TextView likes;
     ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        mProgressBar=findViewById(R.id.progressBar);
        mProgressBar.setVisibility(View.VISIBLE);
        Intent intent=getIntent();
        String imageUrl=intent.getStringExtra(EXTRA_URL);
        String creatername=intent.getStringExtra(EXTRA_CREATERNAME);
        int likecount=intent.getIntExtra(EXTRA_LIKES,0);

        imageView=findViewById(R.id.image_view);
        creater=findViewById(R.id.text_view_creatername);
        likes=findViewById(R.id.text_view_likes);

        Picasso.with(this).load(imageUrl).fit().into(imageView);
        creater.setText(creatername);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mProgressBar.setVisibility(View.INVISIBLE);
            }
        },1500);

        likes.setText("Likes: "+likecount);



    }
}
