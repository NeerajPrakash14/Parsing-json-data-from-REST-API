package test.neeraj.name.com.rest_api;

import android.content.Context;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {

    private Context mContext;
    private ArrayList<ExampleItem> mExampleList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemclickListener(int position);
        void onLinkclickListener(int position);

    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener=listener;
    }


    public ExampleAdapter(Context mContext, ArrayList<ExampleItem> mExampleList) {
        this.mContext = mContext;
        this.mExampleList = mExampleList;
    }



    @NonNull
    @Override
    public ExampleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.example_item, parent, false);

        return new ExampleViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ExampleViewHolder holder, int position) {
        ExampleItem currentitem = mExampleList.get(position);

        final String imageUrl = currentitem.getmImageUrl();
        String creatername = currentitem.getmCreater();
        int likes = currentitem.getMlikes();

        holder.mTextViewCreater.setText(imageUrl);
        holder.mTextViewLikes.setText("Likes: " + likes);
        Picasso.with(mContext).load(imageUrl).fit().into(holder.mImageView);
        Picasso.with(mContext).load(imageUrl).fit().into(holder.mImageView);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Picasso.with(mContext).load(imageUrl).fit().into(holder.mImageView);
            }
        },2500);
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }

    public class ExampleViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mTextViewCreater;
        public TextView mTextViewLikes;
        public Button next_bt1;

        public ExampleViewHolder(View itemView) {
            super(itemView);

            mImageView = itemView.findViewById(R.id.image_view1);
            mTextViewCreater = itemView.findViewById(R.id.text_view_creater);
            mTextViewLikes = itemView.findViewById(R.id.text_view_likes);
            next_bt1=itemView.findViewById(R.id.next_bt);

            next_bt1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION)
                        {
                            mListener.onItemclickListener(position);
                        }
                    }
                }
            });

            mTextViewCreater.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION)
                        {
                            mListener.onLinkclickListener(position);
                        }
                    }
                }
            });

        }
    }
}
