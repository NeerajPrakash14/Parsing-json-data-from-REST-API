package test.neeraj.name.com.rest_api;

public class ExampleItem {

    private String mImageUrl;
    private String mCreater;
    private int mlikes;

    public ExampleItem(String mImageUrl, String mCreater, int mlikes) {
        this.mImageUrl = mImageUrl;
        this.mCreater = mCreater;
        this.mlikes = mlikes;
    }

    public String getmImageUrl() {
        return mImageUrl;
    }

    public String getmCreater() {
        return mCreater;
    }

    public int getMlikes() {
        return mlikes;
    }

    public void setmImageUrl(String mImageUrl) {
        this.mImageUrl = mImageUrl;
    }

    public void setmCreater(String mCreater) {
        this.mCreater = mCreater;
    }

    public void setMlikes(int mlikes) {
        this.mlikes = mlikes;
    }
}
